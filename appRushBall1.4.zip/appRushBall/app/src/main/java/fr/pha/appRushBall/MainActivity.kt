package fr.pha.appRushBall

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import appRushBall.R
import fr.pha.appRushBall.fragments.ConnexionTcpIpFragment
import fr.pha.appRushBall.fragments.JeuFragment
import fr.pha.appRushBall.fragments.ParametrageFragment
import fr.pha.appRushBall.sources.ComClientTcp
import fr.pha.appRushBall.sources.DatasJeu

class MainActivity : AppCompatActivity(),
    ConnexionTcpIpFragment.OnValidationParamsConnexion,
    ParametrageFragment.OnValidationParamsJeu,
    JeuFragment.IJeu {

    //private val _incomingHandler = IncomingHandler(this, Looper.getMainLooper())
    private val _comm: ComClientTcp = ComClientTcp(this)
    private lateinit var tvTrame:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvTrame = findViewById(R.id.tvTrame)
    } // onCreate

    //
    // REACTIONS AUX BOUTONS OU EVENEMENTS DES FRAGMENTS
    //

    // Exécuté à partir du fragment JeuFragment (ANNULATION)
    override fun onFinJeu(params: DatasJeu) {
        val rep = _comm.ordonnerFinPartie(params)
        val mess = findViewById<TextView>(R.id.tvMessReseau)
        mess.text = "En attente de connexion"
        tvTrame.text = rep
        Toast.makeText(
            this,
            "Fin du jeu ! : ${params.mess}",
            Toast.LENGTH_SHORT).show()
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainerView, ConnexionTcpIpFragment.newInstance(
                params.login, params.password, params.adresseIP, params.portTCP.toString(),
                rep, "-", "Attente de connexion"
            )).commit()
    } // fun

    // Exécuté à partir du fragment JeuFragment (MISE A JOUR SCORES)
  //  override fun onJeuEnCours(params: DatasJeu) {
  //      Toast.makeText(
    //        this,
      //      "Jeu en cours : ${params.mess}",
        //    Toast.LENGTH_SHORT).show()
        //_comm.lireEnPermanenceLeServeurRushball()
   // } // fun

    // Exécuté à partir du fragment JeuFragment (Lancement de la réception des scores)
    override fun onStartJeu(params: DatasJeu) {
        _comm.lireEnPermanenceLeServeurRushball()
        Toast.makeText(
            this,
            "Lancement réception",
            Toast.LENGTH_SHORT).show()
    } // fun

    //  Exécuté à partir du fragment ParametrageFragment
    override fun onValidationParamsJeu(params: DatasJeu) {
        val mess:String
        val rep = _comm.parametrer(params)
        tvTrame.text = rep
        when  {
            rep.indexOf("OK", 0, false)>=0 -> {
                mess = "Params enregistrés : ${params.params}"
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, JeuFragment.newInstance(
                        params.login, params.password, params.adresseIP, params.portTCP.toString(),
                        rep, params.params, "JEU COMMENCE"
                    )).commit()
            } // OK
            else -> {
                mess = "Params KO : ${params.params}" // on reste sur le fragment Param
            } // KO
        } // when
        Toast.makeText(
            this,
            "Jeu en cours avec le paramétrage : $mess",
            Toast.LENGTH_SHORT).show()
    } // fun

    //  Exécuté à partir du fragment ConnexionTcpIpFragment
    override fun onValidationParamsConnexion(params: DatasJeu) {
        var mess = "Connexion valide à ${params.adresseIP} Port=${params.portTCP} !"
        val rep = _comm.authentifier(params)
        tvTrame.text = rep
        when (rep.split('|')[1].split(';')[2]) {  // etat
            "0" -> {  // Paramétrage à faire
                supportFragmentManager.beginTransaction()
                    .replace(R.id.fragmentContainerView, ParametrageFragment.newInstance(
                        params.login, params.password, params.adresseIP, params.portTCP.toString(),
                        rep, "0", mess))
                    .commit()
            } // 0
            "E" -> { // jeu en cours
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, JeuFragment.newInstance(
                        params.login, params.password, params.adresseIP, params.portTCP.toString(),
                        rep, "E", mess))
                    .commit()
            } // E
            else -> {
                mess = "Connexion impossible à ${params.adresseIP} Port=${params.portTCP} !"
            } // else
        } // when
        val tvMess = findViewById<TextView>(R.id.tvMessReseau)
        tvMess.text = mess
        Toast.makeText(
            this,
            mess,
            Toast.LENGTH_SHORT).show()
    } // fun

} // main
