package fr.pha.appRushBall.sources

class CProtocoleClient {

    fun prepReqAuth(datasJeu: DatasJeu): String {
        var req = ":X|M;"
        req += datasJeu.login.padStart(13) + ";"
        req += datasJeu.password.padStart(13) + "|XX:"
        val crc = calculerCrc16(req)
        // TODO placer le CRC dans la trame
        return req
    } // fun

    fun prepReqParams(params:String):String {
        var req = ":P|$params|XX:"
        val crc = calculerCrc16(req)
        // TODO placer le CRC dans la trame
        return req
    } // fun

    fun prepReqFin(datasJeu: DatasJeu): String {
        var req = ":Z|1|XX:"
        val crc = calculerCrc16(req)
        // TODO placer le CRC dans la trame
        return req
    } // fun

    suspend fun decoderTrame(trame:String): List<String> {
        var liste:List<String> = listOfNotNull()
        // vérification crc16

        // traitement de la trame des scores
        return  when {
            trame.startsWith(":S|") -> decoderTrameScore(trame)
            else -> liste
        } /// when
    } // decoderTrame

    private fun decoderTrameScore(trame: String):List<String> {
        val scores = trame.split('|')
        val nbJoueurs = scores[1].split(';')[0]
        val qui = scores[1].split(';')[1]
        val finJeu = scores[1].split(';')[2]
        var liste = listOf("Nombre de joueurs : $nbJoueurs",
            "Le tour est à Joueur${qui.toInt()}",
            when (finJeu) {
                "0" -> "Fin du jeu : NON"
                else -> "Fin du jeu : OUI"
            })
        for (i in 0..3) {
            liste += "Score ${scores[1].split(';')[3+2*i]} : ${scores[1].split(';')[4+2*i]}"
        } // for
        return liste
    }

    private fun calculerCrc16(req: String):UInt {
        return 4627u
    } // fun
}