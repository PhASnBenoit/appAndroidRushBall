package fr.pha.appRushBall.sources

import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.TextView
import appRushBall.R
import fr.pha.appRushBall.MainActivity
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Socket

const val TIMEOUT:Long = 5000

class ComClientTcp(activity: MainActivity) { // class
    private var _finThread: Boolean = false //
    private var _activity:MainActivity = activity
    private var _sock: Socket? = null
    private lateinit var _writer:OutputStream
    private lateinit var _reader: InputStream
    private var _prot = CProtocoleClient()
    private var _fini = false
    private lateinit var _arrayAdapter:ArrayAdapter<String>

    //
    // METHODES PUBLIQUES ------------------------------------------------------------------------
    //
    fun authentifier(datasJeu: DatasJeu): String {
        val one = CoroutineScope(Dispatchers.IO).async {
            if (connecterToServer(datasJeu.adresseIP, datasJeu.portTCP) )
                login(datasJeu) // le retour de login va dans one
            else
                "Connexion impossible !"
        } // async
        var rep: String
        runBlocking {
            rep = one.await()
        } // runB
        return rep
    } // fun authentifier

    fun parametrer(datasJeu: DatasJeu): String {
        val one = CoroutineScope(Dispatchers.IO).async {
            params(datasJeu) // le retour de params va dans one
        } //async
        var rep: String
        runBlocking {
            rep = one.await()
         } // runB
        return rep
    } // fun authentifier

    fun ordonnerFinPartie(datasJeu: DatasJeu): String {
        val one = CoroutineScope(Dispatchers.IO).async {
            stopperLireEnPermanenceLeServeurRushball()
            waitForEndReading() // attend la fin du thread de lecture
            finir(datasJeu) // le retour de params va dans one
        } // async
        var rep: String
        runBlocking {
            rep = one.await()
        } // runB
        //_sock.close()
        return rep
    } // fun authentifier

    fun lireEnPermanenceLeServeurRushball() {
        _finThread = false
        _fini = false
        CoroutineScope(Dispatchers.Main).launch(Dispatchers.IO) {
            while (!_fini) {
                val rep = readWithTimeout(TIMEOUT)
                val lines = _prot.decoderTrame(rep)
                // MISE A JOUR DE L'AFFICHAGE
                if (lines.isNotEmpty()) {
                    _activity.runOnUiThread {
                        val lvLog = _activity.findViewById<ListView>(R.id.lvLog)
                        val tvTrame = _activity.findViewById<TextView>(R.id.tvTrame)
                        tvTrame.text = rep
                        _arrayAdapter =
                            ArrayAdapter(_activity, android.R.layout.simple_list_item_1, lines)
                        lvLog.adapter = _arrayAdapter  // met à jour la liste des scores
                    } // runOnUiThread
                } // if
            } // wh
            _finThread = true
        } // launch
     } // fun

    //
    // METHODES PRIVEES -------------------------------------------------------------------------
    //
    private fun stopperLireEnPermanenceLeServeurRushball() {
        _fini = true
    } // fun

    private fun finir(datasJeu: DatasJeu):String {
        var rep:String
        try {
            // préparation de la requete
            val req = _prot.prepReqFin(datasJeu)
            _writer.write(req.toByteArray())
            rep = readWithTimeout(TIMEOUT)
        } catch (e: Exception) {
            rep = e.message.toString()
            println(rep)
        } // catch
        return rep
    }

    private fun connecterToServer(adresseIP: String, portTCP: Int):Boolean {
        return try {
            if (_sock == null) {
                _sock = Socket(adresseIP, portTCP)
                _writer = _sock!!.getOutputStream()
                _reader = _sock!!.inputStream
            } // isConnected
            _sock != null
        } catch (e:Exception) {
            false
        } // catch
    } // fun

    private fun login(datasJeu: DatasJeu):String {
        var rep:String
        try {
            // préparation de la requete
            val req = _prot.prepReqAuth(datasJeu)
            _writer.write(req.toByteArray())
            rep = readWithTimeout(TIMEOUT)
        } catch (e: Exception) {
            rep = "KO"
            println(rep)
        } // catch
        return rep
    } // fun

    private fun params(datasJeu: DatasJeu):String {
        return try {
            // préparation de la requete
            val req = _prot.prepReqParams(datasJeu.params)
            _writer.write(req.toByteArray())
            readWithTimeout(TIMEOUT)
        } catch (e: Exception) {
            e.message.toString()
        } // catch
        //return rep
    }

    private fun readWithTimeout(duree:Long):String {
        // timeout de lecture
        var rep = "KO"
        try {
            var tempo: Long = 0
            val delta: Long = 200
            val bReader = BufferedReader(InputStreamReader(_reader))
            while (tempo < duree) {
                runBlocking {
                    delay(delta)  // ne peut se faire que dans un contexte coroutine
                } // runBlocking
                val nb = _reader.available()
                if (nb > 0) {
                    rep = bReader.readLine()
                    break
                } // if
                tempo += delta
            } // while
            if (tempo == duree) {
                rep = "KO"
            } // if
        } catch (e: Exception) {
            rep = "KO"
        } // catch
        return rep
    } // fun readWithTimeout

    private fun waitForEndReading():Boolean {
        while (!_finThread);
        _finThread = false
        return true
    } // fun
} // class