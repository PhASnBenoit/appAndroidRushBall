package fr.pha.appRushBall.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import appRushBall.R
import fr.pha.appRushBall.sources.DatasJeu

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_LOGIN = "_login"
private const val ARG_PASSWORD = "_password"
private const val ARG_ADRIP = "_adrIp"
private const val ARG_PORTTCP = "_portTCP"
private const val ARG_TRAME = "_trame"
private const val ARG_PARAMS = "_params"
private const val ARG_MESS = "_mess"

/**
 * A simple [Fragment] subclass.
 * Use the [ParametrageFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ParametrageFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private lateinit var _login: String
    private lateinit var _password: String
    private lateinit var _adrIp: String
    private lateinit var _portTCP: String
    private lateinit var _trame: String
    private lateinit var _params: String
    private lateinit var _mess: String
    private lateinit var listener: OnValidationParamsJeu

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnValidationParamsJeu) {
            listener = context
        } else {
            throw ClassCastException("$context must implement params jeu.")
        } // else
    } // fun

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            _login = it.getString(ARG_LOGIN).toString()
            _password = it.getString(ARG_PASSWORD).toString()
            _adrIp = it.getString(ARG_ADRIP).toString()
            _portTCP = it.getString(ARG_PORTTCP).toString()
            _trame = it.getString(ARG_TRAME).toString()
            _params = it.getString(ARG_PARAMS).toString()
            _mess = it.getString(ARG_MESS).toString()
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val rootV = inflater.inflate(R.layout.fragment_parametrage, container, false)

        if (savedInstanceState == null) {
            // init IHM mode de jeu
            val rbModeM = rootV.findViewById<RadioButton>(R.id.rbMoitier)
            rbModeM.isChecked = true
            // Init du spinner NbJoueurs
            val sNbJoueurs: Spinner = rootV.findViewById(R.id.sNbJoueurs)
            initSpinner(sNbJoueurs, R.array.nbJoueurs_array)
            sNbJoueurs.setSelection(3)
            // Init du spinner NbPanneaux
            val sNbPanneaux: Spinner = rootV.findViewById(R.id.sNbPanneaux)
            initSpinner(sNbPanneaux, R.array.nbPanneaux_array)
            sNbPanneaux.setSelection(0)
            // Init du spinner Score max
            val sScoreMax: Spinner = rootV.findViewById(R.id.sScoreMax)
            initSpinner(sScoreMax, R.array.scoresMax_array)
            sScoreMax.setSelection(0)
            // init spinner nb de points par faute
            val sNbPointsFaute: Spinner = rootV.findViewById(R.id.sNbPointsFaute)
            initSpinner(sNbPointsFaute, R.array.nbPoints_array)
            sNbPointsFaute.setSelection(2)
            // Init des spinner NbPoints
            val tabSpinners = intArrayOf(
                R.id.sPointsRouge, R.id.sPointsVert,
                R.id.sPointsBleu, R.id.sPointsMagenta,
                R.id.sPointsCyan, R.id.sPointsBlanc,
                R.id.sPointsJoker
            )
            var i = 0
            tabSpinners.forEach {
                val stabPoints: Spinner = rootV.findViewById(it)
                initSpinner(stabPoints, R.array.nbPoints_array)
                stabPoints.setSelection(i)
                i += 1
            } // foreach

            val btParams = rootV.findViewById<Button>(R.id.btParams)
            btParams.setOnClickListener {
                // TO DO : Contrôler params

                //  sérialisation des paramètres sous forme de chaine de caractères pré formaté
                // selon le protocole Client TCP Rushball
                val etNom1 = rootV.findViewById<EditText>(R.id.etJoueur1)
                val etNom2 = rootV.findViewById<EditText>(R.id.etJoueur2)
                val etNom3 = rootV.findViewById<EditText>(R.id.etJoueur3)
                val etNom4 = rootV.findViewById<EditText>(R.id.etJoueur4)
                var str: String = etNom1.text.toString().trim()
                var paramsDuJeu = sNbJoueurs.selectedItem.toString() + "|"
                paramsDuJeu += str.padStart(13) + ";"  // ajout d'espace
                str = etNom2.text.toString().trim()
                paramsDuJeu += str.padStart(13) + ";"
                str = etNom3.text.toString().trim()
                paramsDuJeu += str.padStart(13) + ";"
                str = etNom4.text.toString().trim()
                paramsDuJeu += str.padStart(13)
                if (rbModeM.isChecked) {
                     paramsDuJeu += "|M;"
                }
                val rbModeP = rootV.findViewById<RadioButton>(R.id.rbToutes)
                if (rbModeP.isChecked) {
                    paramsDuJeu += "|P;"
                }
                val rbModeB = rootV.findViewById<RadioButton>(R.id.rbUne)
                if (rbModeB.isChecked) {
                    paramsDuJeu += "|B;"
                }
                paramsDuJeu += "S;"   // ajout de mode de fin de jeu figé sur score
                paramsDuJeu += sScoreMax.selectedItem.toString().padStart(3, '0')
                paramsDuJeu += "|" + sNbPointsFaute.selectedItem.toString() + "|"
                paramsDuJeu += sNbPanneaux.selectedItem.toString() + ";"
                val nbCA: Int = sNbPanneaux.selectedItem.toString().toInt() * 3 / 2
                paramsDuJeu += nbCA.toString().padStart(2, '0')
                paramsDuJeu += "|1;"
                val sJoker = rootV.findViewById<Spinner>(R.id.sPointsJoker)
                paramsDuJeu += sJoker.selectedItem.toString()
                paramsDuJeu += "|6|"
                for (j in 0..5) {
                    val spinner = rootV.findViewById<Spinner>(tabSpinners[j])
                    paramsDuJeu += "${j + 1};" + spinner.selectedItem.toString()
                    if (j < 5)
                        paramsDuJeu += ";"
                } // for

                // listener pour échanger avec l'activité
                listener.onValidationParamsJeu(
                    DatasJeu(_login, _password, _adrIp, _portTCP.toInt(), "", paramsDuJeu, "Paramètres validés")
                )
            } // listener
        } // if
        return rootV
    } //

    private fun initSpinner(spi: Spinner, tab: Int) {
        val adapt = activity?.let {
            ArrayAdapter.createFromResource(
                it.baseContext,
                tab, android.R.layout.simple_spinner_item)
        }
        // Specify the layout to use when the list of choices appears
        adapt?.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item)
        // Apply the adapter to the spinner
        spi.adapter = adapt
    } // fun

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param login Parameter 1.
         * @param password Parameter 2.
         * @param adrIP Parameter 3.
         * @param portTCP Parameter 4.
         * @param trame Parameter 5.
         * @param params Parameter 6.
         * @param mess Parameter 7.
         * @return A new instance of fragment ParametrageFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(login:String, password:String, adrIP:String, portTCP:String, trame:String, params:String, mess:String) =
            ParametrageFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_LOGIN, login)
                    putString(ARG_PASSWORD, password)
                    putString(ARG_ADRIP, adrIP)
                    putString(ARG_PORTTCP, portTCP)
                    putString(ARG_TRAME, trame)
                    putString(ARG_PARAMS, params)
                    putString(ARG_MESS, mess)
                } // apply
            } // fun
    } // companion

    // Communication avec l'activité
    interface OnValidationParamsJeu {
        fun onValidationParamsJeu(params: DatasJeu)
    } // interface
} // fragment
