package fr.pha.appRushBall.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import appRushBall.R
import fr.pha.appRushBall.sources.DatasJeu

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_LOGIN = "_login"
private const val ARG_PASSWORD = "_password"
private const val ARG_ADRIP = "_adrIp"
private const val ARG_PORTTCP = "_portTCP"
private const val ARG_TRAME = "_trame"
private const val ARG_PARAMS = "_params"
private const val ARG_MESS = "_mess"

/**
 * A simple [Fragment] subclass.
 * Use the [JeuFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class JeuFragment : Fragment() {
    // TODO: Rename and change types of parameters
    private lateinit var _login: String
    private lateinit var _password: String
    private lateinit var _adrIp: String
    private lateinit var _portTCP: String
    private lateinit var _param: String
    private lateinit var _trame: String
    private lateinit var _mess: String
    private lateinit var listener: IJeu

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is IJeu) {
            listener = context
        } else {
            throw ClassCastException("$context must implement IJeu.")
        } // else
    } // fun

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            _login = it.getString(ARG_LOGIN).toString()
            _password = it.getString(ARG_PASSWORD).toString()
            _adrIp = it.getString(ARG_ADRIP).toString()
            _portTCP = it.getString(ARG_PORTTCP).toString()
            _trame = it.getString(ARG_TRAME).toString()
            _param = it.getString(ARG_PARAMS).toString()
            _mess = it.getString(ARG_MESS).toString()
        } // let
    } // fun

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        // Inflate the layout for this fragment
        val rootV = inflater.inflate(R.layout.fragment_jeu, container, false)
        if (savedInstanceState == null) {
            val tvParam = rootV.findViewById<TextView>(R.id.tvParams)

            tvParam.text = _param
            listener.onStartJeu(
                DatasJeu(
                    _login, _password, _adrIp, _portTCP.toInt(), _trame, _param, "JEU EN COURS"
                )
            )

            val btFinJeu = rootV.findViewById<Button>(R.id.btFinJeu)
            btFinJeu.setOnClickListener {
                // intent pour échanger avec l'activité
                listener.onFinJeu(
                     DatasJeu(
                         _login, _password, _adrIp, _portTCP.toInt(),
                         _trame, _param, "FIN JEU"
                     )
                )
            } // listener
        } // if save

        return rootV
    }

    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param login Parameter 1.
         * @param password Parameter 2.
         * @param adrIP Parameter 3.
         * @param portTCP Parameter 4.
         * @param trame Parameter 5.
         * @param params Parameter 6.
         * @param mess Parameter 7.
         * @return A new instance of fragment JeuFragment.
         */
        // TODO: Rename and change types and number of parameters
        @JvmStatic
        fun newInstance(login:String, password:String, adrIP:String, portTCP:String, trame:String, params:String, mess:String) =
            JeuFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_LOGIN, login)
                    putString(ARG_PASSWORD, password)
                    putString(ARG_ADRIP, adrIP)
                    putString(ARG_PORTTCP, portTCP)
                    putString(ARG_TRAME, trame)
                    putString(ARG_PARAMS, params)
                    putString(ARG_MESS, mess)
                } // apply
            } // apply
    } // companion

    // Communication vers l'activité
    interface IJeu {
        fun onFinJeu(params: DatasJeu)
        //fun onJeuEnCours(params: DatasJeu)
        fun onStartJeu(params: DatasJeu)
    } // interface
} // fragment