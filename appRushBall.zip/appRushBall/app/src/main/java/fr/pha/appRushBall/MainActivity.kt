package fr.pha.appRushBall

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import appRushBall.R
import fr.pha.appRushBall.fragments.ConnexionTcpIpFragment
import fr.pha.appRushBall.fragments.JeuFragment
import fr.pha.appRushBall.fragments.ParametrageFragment
import fr.pha.appRushBall.sources.ComClientTcp
import fr.pha.appRushBall.sources.DatasJeu

class MainActivity : AppCompatActivity(),
    ConnexionTcpIpFragment.OnValidationParamsConnexion,
    ParametrageFragment.OnValidationParamsJeu,
    JeuFragment.IJeu {

    //private val _incomingHandler = IncomingHandler(this, Looper.getMainLooper())
    private val _comm: ComClientTcp = ComClientTcp(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    } // onCreate

    // Exécuté à partir du fragment JeuFragment (ANNULATION)
    override fun onFinJeu(params: DatasJeu) {
        Toast.makeText(
            this,
            "Fin du jeu demandée : ${params.mess}",
            Toast.LENGTH_SHORT).show()
        _comm.stopperLireEnPermanenceLeServeurRushball()
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainerView, ConnexionTcpIpFragment(), "connexion")
            .commit()
    } // fun

    // Exécuté à partir du fragment JeuFragment (MISE A JOUR SCORES)
    override fun onJeuEnCours(params: DatasJeu) {
        Toast.makeText(
            this,
            "Jeu en cours : ${params.mess}",
            Toast.LENGTH_SHORT).show()
        _comm.lireEnPermanenceLeServeurRushball(params)
    } // fun

    // Exécuté à partir du fragment JeuFragment (Lancement de la réception des scores)
    override fun onStartJeu(params: DatasJeu) {
        Toast.makeText(
            this,
            "Lancement réception",
            Toast.LENGTH_SHORT).show()
        _comm.lireEnPermanenceLeServeurRushball(params)
    } // fun

    //  Exécuté à partir du fragment ParametrageFragment
    override fun onValidationParamsJeu(params: DatasJeu) {
        var mess = "Connexion impossible à ${params.adresseIP} Port=${params.portTCP} !"
        val rep = _comm.on_parametrer(params)
        if (rep.isEmpty()) {
            mess = "Params OK : ${params.params}"
        }
        supportFragmentManager
            .beginTransaction()
            .replace(R.id.fragmentContainerView, JeuFragment.newInstance(
                params.login, params.password, params.adresseIP, params.portTCP.toString(), mess, mess
            )).commit()
        Toast.makeText(
            this,
            "Jeu en cours avec le paramétrage : $mess",
            Toast.LENGTH_SHORT).show()
        val tvMess = findViewById<TextView>(R.id.tvMessReseau)
        tvMess.text = mess
    } // fun

    //  Exécuté à partir du fragment ConnexionTcpIpFragment
    override fun onValidationParamsConnexion(params: DatasJeu) {
        var mess = "Connexion impossible à ${params.adresseIP} Port=${params.portTCP} !"
        val rep = _comm.on_authentifier(params)
        if (rep.startsWith(":X|OK")) {
            mess = "Connecté à ${params.adresseIP} Port=${params.portTCP} !"
            val param = rep.split('|')[1].split(';')[2]
            if (param == "0") {
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, ParametrageFragment.newInstance(
                        params.login, params.password, params.adresseIP, params.portTCP.toString()))
                    .commit()
            } else {
                supportFragmentManager
                    .beginTransaction()
                    .replace(R.id.fragmentContainerView, JeuFragment.newInstance(
                        params.login, params.password, params.adresseIP,
                        params.portTCP.toString(), "no config", "Reconnexion !"))
                    .commit()
            } // else
        } // if
        Toast.makeText(
            this,
            mess,
            Toast.LENGTH_SHORT).show()
        val tvMess = findViewById<TextView>(R.id.tvMessReseau)
        tvMess.text = mess
    } // fun

} // main
