package fr.pha.appRushBall.sources

data class DatasJeu(
    val login:String = "login",
    val password:String = "password",
    var adresseIP: String = "192.168.X.X",
    var portTCP:Int = 4444,
    var params: String = "TO DO !",
    var mess: String = "R.A.S"
)
// var params: String = ":P|4|           J1;           J2;           J3;           J4|M;P;100|3|1;001|1;005|6|1;1;2;2;3;3;4;4;5;5;6;6|XXXX:",