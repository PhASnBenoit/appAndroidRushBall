package fr.pha.appRushBall.sources

import android.widget.ArrayAdapter
import android.widget.ListView
import appRushBall.R
import fr.pha.appRushBall.MainActivity
import kotlinx.coroutines.*
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.Socket

const val TIMEOUT:Long = 1000

class ComClientTcp(activity: MainActivity) {
    private var _activity:MainActivity = activity
    private lateinit var _sock:Socket
    private lateinit var _writer:OutputStream
    private lateinit var _reader: InputStream
    private var _prot = CProtocoleClient()
    private var _fini = false
    private lateinit var _arrayAdapter:ArrayAdapter<String>

    //
    // METHODES PUBLIQUES ------------------------------------------------------------------------
    //
    fun on_authentifier(datasJeu: DatasJeu): String {
        val one = CoroutineScope(Dispatchers.IO).async {
            login(datasJeu) // le retour de login va dans one
        }
        var rep: String
        runBlocking {
            rep = one.await()
        }
        return rep
    } // fun authentifier

    fun on_parametrer(datasJeu: DatasJeu): String {
        val one = CoroutineScope(Dispatchers.IO).async {
            sendParams(datasJeu) // le retour de sendParams va dans one
        }
        var rep: String
        runBlocking {
            rep = one.await()
         }
        return rep
    } // fun authentifier

    fun stopperLireEnPermanenceLeServeurRushball() {
        _fini = true
    } // fun

    fun lireEnPermanenceLeServeurRushball(datasJeu: DatasJeu) {
        CoroutineScope(Dispatchers.Main).launch(Dispatchers.IO) {
            //connecterToServer(datasJeu.adresseIP, datasJeu.portTCP)
            while (!_fini) {
                val rep = readWithTimeout(TIMEOUT)
                if (rep.startsWith(":S|")) {
                    val scores = rep.split('|')
                    // MISE A JOUR DE L'AFFICHAGE
                    _activity.runOnUiThread {
                        val lvLog = _activity.findViewById<ListView>(R.id.lvLog)
                        _arrayAdapter = ArrayAdapter(_activity, android.R.layout.simple_list_item_1, scores)
                        lvLog.adapter = _arrayAdapter
                    } // runOnUiThread
                } // if rep
            } // wh
            _sock.close()
        } // coroutine
     } // fun


    //
    // METHODES PRIVEES -------------------------------------------------------------------------
    //
    private fun connecterToServer(adresseIP: String, portTCP: Int) {
        _sock = Socket(adresseIP, portTCP)
        _writer = _sock.getOutputStream()
        _reader = _sock.inputStream
    } // fun

    private fun login(datasJeu: DatasJeu):String {
        var rep:String
        try {
            // préparation de la requete
            val req = _prot.prepReqAuth(datasJeu)
            connecterToServer(datasJeu.adresseIP, datasJeu.portTCP)
            _writer.write(req.toByteArray())
            rep = readWithTimeout(TIMEOUT)
            //_sock.close()  // on ne ferme qu'à la fin du jeu
        } catch (e: Exception) {
            rep = e.message.toString()
            println(rep)
        } // catch
        return rep
    } // fun

    private fun sendParams(datasJeu: DatasJeu):String {
        var rep = ""
        try {
            // préparation de la requete
            val req = _prot.prepReqParams(datasJeu.params)
            //connecterToServer(datasJeu.adresseIP, datasJeu.portTCP)
            _writer.write(req.toByteArray())
            //_sock.close()
        } catch (e: Exception) {
            rep = e.message.toString()
            println(rep)
        } // catch
        return rep
    }

    private fun readWithTimeout(duree:Long):String {
        // timeout de lecture
        var rep = "Rien lu !"
        var tempo: Long = 0
        val delta: Long = 50
        val bReader = BufferedReader(InputStreamReader(_reader))
            while (tempo < duree) {
                runBlocking {
                    delay(delta)  // ne peut se faire que dans un contexte coroutine
                } // runBlocking
                val nb = _reader.available()
                if (nb > 0) {
                    rep = bReader.readLine()
                    break
                } // if
                tempo += delta
            } // while
        if (tempo == duree) {
            rep = "0"
        } // if
        return rep
    } // fun readWithTimeout
} // class