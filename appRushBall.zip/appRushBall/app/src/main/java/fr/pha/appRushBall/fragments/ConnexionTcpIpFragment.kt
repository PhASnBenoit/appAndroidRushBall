package fr.pha.appRushBall.fragments

import android.content.Context
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import appRushBall.R
import fr.pha.appRushBall.sources.DatasJeu

// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "adrIP"
private const val ARG_PARAM2 = "portTCP"

/**
 * A simple [Fragment] subclass.
 * Use the [ConnexionTcpIpFragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class ConnexionTcpIpFragment : Fragment() {
    private var adrIP: String? = null
    private var portTCP: String? = null
    private lateinit var listener: OnValidationParamsConnexion

    override fun onAttach(context: Context) {
        super.onAttach(context)
        if (context is OnValidationParamsConnexion) {
            listener = context
        } else {
            throw ClassCastException("$context must implement params.")
        } // else
    } // fun

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            adrIP = it.getString(ARG_PARAM1)
            portTCP = it.getString(ARG_PARAM2)
        }
    } // onCreate

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val rootV =  inflater.inflate(R.layout.fragment_connexion_tcp_ip, container, false)

        if (savedInstanceState == null) {
            val etLogin = rootV.findViewById<EditText>(R.id.etEmailAddress)
            val etPass = rootV.findViewById<EditText>(R.id.etPassword)
            val etAdresseIP = rootV.findViewById<EditText>(R.id.etAdresseIp)
            val etPortTCP = rootV.findViewById<EditText>(R.id.etPortTcp)
            val btConnecter = rootV.findViewById<Button>(R.id.btConnecter)

            btConnecter.setOnClickListener {
                Toast.makeText(
                    activity?.baseContext,
                    "Validation des paramètres de connexion....",
                    Toast.LENGTH_SHORT
                ).show()

                // TO DO : Contrôler params


                // Provoque l'exécution de la fonction dans MainActivity
                listener.onValidationParamsConnexion(
                    DatasJeu(
                        etLogin.text.toString(),
                        etPass.text.toString(),
                        etAdresseIP.text.toString(),
                        etPortTCP.text.toString().toInt()
                    )
                )
            } // listener
        } // if saved
        return rootV
    } // onCreateView

    // pour recevoir des paramètres en entrée du fragment
    companion object {
        /**
         * Use this factory method to create a new instance of
         * this fragment using the provided parameters.
         *
         * @param adrIP Parameter 1.
         * @param portTCP Parameter 2.
         * @return A new instance of fragment ConnexionTcpIpFragment.
         */
        @JvmStatic
        fun newInstance(adrIP: String, portTCP: String) =
            ConnexionTcpIpFragment().apply {
                arguments = Bundle().apply {
                    putString(ARG_PARAM1, adrIP)
                    putString(ARG_PARAM2, portTCP)
                } // arguments
            } // newInstance
    } // object

    // Communication avec l'activité qui vient du fragment ConnexionTcpIpFragment
    interface OnValidationParamsConnexion {
        fun onValidationParamsConnexion(params: DatasJeu)
    } // interface

} // ConnexionTcpIpFragment

