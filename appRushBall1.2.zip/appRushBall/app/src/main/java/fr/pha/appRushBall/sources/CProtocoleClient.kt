package fr.pha.appRushBall.sources

class CProtocoleClient {

    fun prepReqAuth(datasJeu: DatasJeu): String {
        var req = ":X|M;"
        req += datasJeu.login.padStart(13) + ";"
        req += datasJeu.password.padStart(13) + "|XX:"
        val crc = calculerCrc16(req)
        // TODO placer le CRC dans la trame
        return req
    } // fun

    fun prepReqParams(params:String):String {
        var req = ":P|"
        req += params+"|XX:"
        val crc = calculerCrc16(req)
        // TODO placer le CRC dans la trame
        return req
    } // fun

    private fun calculerCrc16(req: String):UInt {
        return 4627u
    } // fun
}